    # Sistema de Notas - Backend (FastAPI)

    Proyecto ejemplo: API REST para un sistema de notas con autenticación (JWT), usando **FastAPI** y **SQLite**.

    ## Características
    - Registro de usuarios.
    - Login (OAuth2 password flow) que devuelve un token JWT.
    - CRUD de notas (cada nota pertenece a un usuario).
    - Documentación automática con Swagger (accesible en `/docs`) y ReDoc (`/redoc`).

    ## Archivos incluidos
    - `main.py` - aplicación FastAPI principal.
    - `requirements.txt` - dependencias.
    - `README.md` - este archivo.

    ## Uso rápido

    1. Crear un entorno virtual e instalar dependencias:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2. Ejecutar la app con uvicorn:

```bash
uvicorn main:app --reload
```

3. Abrir Swagger UI:
- http://127.0.0.1:8000/docs

## Notas
- Cambia `SECRET_KEY` en `main.py` antes de usar en producción.
- Para usar PostgreSQL o MySQL, cambia `DATABASE_URL` y la configuración de `create_engine`.
